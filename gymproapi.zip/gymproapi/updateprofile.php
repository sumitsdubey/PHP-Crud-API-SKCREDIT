<?php

require_once __DIR__.'/function.php';
require_once __DIR__.'/class/Query.php';

if($_SERVER['REQUEST_METHOD']=='POST'){

    $gymname = post('gym_name');
    $ownername = post('owner_name');
    $address = post('address');
    $email = post('email');
    $mobile = post('mobile');;

    $update = mysqli_query($conn, "UPDATE `users` 
    SET `gym_name` = '$gymname', `owner_name` = '$ownername', `mobile` = '$mobile', `address` = '$address'
     WHERE `users`.`email` = '$email'"
);
    $query = new Query();


    // $update = $query->update('users',[
	// 	'gym_name'=> $gymname,
	// 	'owner_name'=>$ownername,
    //     'address' => $address,
    //     'mobile'=> $mobile,
	//   ])->where('email',$email)->commit();

    if($update){
        echo json_encode(
            [
                'code' => 200,
                'message'=> "Profile Updated Successfully",
                'status' => true,
                'data' => [$update],
                'error' => false
            ]
        ,JSON_PRETTY_PRINT);
        exit;
    }else{
        echo json_encode(
            [
                'code' => 200,
                'message'=> "Profile Not Updated ",
                'status' => false,
                'data' => [],
                'error' => false
            ]
        ,JSON_PRETTY_PRINT);
        exit;
    }

}else{
    echo json_encode(
        [
            'code' => 201,
            'message'=> "Invalid Request Please Send POST request",
            'status' => false,
            'data' => [],
            'error'=> true
        ], JSON_PRETTY_PRINT
    );
    exit;
}


?>