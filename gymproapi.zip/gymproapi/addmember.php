<?php


require_once __DIR__.'/function.php';
require_once __DIR__.'/class/Query.php';
require_once __DIR__.'/mymailer.php';


header("Content-Type:application/json");

if($_SERVER['REQUEST_METHOD']=='POST'){
     
    $query = new Query();

    $name = post('member_name');
    $mobile = post('member_mobile');
    $address = post('member_address');
    $join_date = post('member_joindate');
    $created_by = post('member_createdby');
    $creater_gym = post('created_gymname');
    $joining_fee = post('joining_fee');

    $result = $query->select('*')->table('members')->where(['mobile'=> $mobile])->AllRecords();

    if($result){
        echo json_encode([
            'code' => 200,
            'message' => 'Member Already Exist',
            'status' => false
        ],JSON_PRETTY_PRINT);
        exit;

    }else{
        if($name =="" || $mobile =="" || $join_date=="" || $created_by==""){
            echo json_encode([
                'code' => 404,
                'message'=> 'Please Provide Value',
                'status' => false
                
            ],JSON_PRETTY_PRINT);
            exit;
        }
    
        try{
        $datasend = $query->insert('members',[
            'name'=> $name,
            'mobile'=> $mobile,
            'address'=> $address,
            'join_date'=> $join_date,
            'created_by'=> $created_by,
            'creater_gym'=> $creater_gym,
            'fee'=> $joining_fee
        ]);
    
        echo json_encode([
            'code' => 200,
            'message'=> 'Member Registerd Successfully',
            'status' => true,
            
        ],JSON_PRETTY_PRINT);
        exit;
        }catch(Exception $e){
            echo json_encode([
                'code' => 200,
                'message'=> 'Error in Server',
                'status' => false
        
            ],JSON_PRETTY_PRINT);
            exit;
        }

    }

    

}else{

    echo json_encode([
        'code' => 201,
        'message'=> 'Invalid Request Please Send POST request.',
        'status' => false


    ],JSON_PRETTY_PRINT);
    exit;
}



?>