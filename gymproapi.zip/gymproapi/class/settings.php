<?php

//This is Setting file

################ All Constants ##########################
define('HOST','localhost');
define('USER','root');
define('PASSWORD','');
define('DBNAME','gympro_data');
define('BASE_URL','localhost/gymproapi');

################ All Constants ##########################

return [
	
	'db:config'=>[
		
		'host'=>'localhost', //localhost 3306 : sql port
		'user'=>'id20578384_gympro', //username: root
		'password'=>'Sumit@123', // Blank
		'dbname'=>'id20578384_gympro_data', 
	],
	'connection:debug'=>false,

];
?>