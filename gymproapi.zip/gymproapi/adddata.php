<?php


require_once __DIR__.'/function.php';
require_once __DIR__.'/class/Query.php';

header("Content-Type:application/json");

if($_SERVER['REQUEST_METHOD']=='POST'){

    // REQUEST_CODE = 0 FOR ADD NOTES ***********

    $request_code = post('request_code');

    if ($request_code == 0){
        $created_by = post('created_by');
        $title = post('title');
        $notes = post('notes');
   
     
        $query = new Query();


        try{
            $datasend = $query->insert('notes',[
            'created_by'=> $created_by,
            'title'=> $title,
            'notes'=> $notes
       
    ]);

         echo json_encode([
            'code' => 200,
            'message'=> 'Notes Add Success',
            'status' => true,
        
        ],JSON_PRETTY_PRINT);
        exit;
        }catch(Exception $e){
             echo json_encode([
                'code' => 200,
                'message'=> 'Some Error Ouccured',
                'status' => false
    
    
            ],JSON_PRETTY_PRINT);
             exit;
    }
    }
    

}else{

    echo json_encode([
        'code' => 201,
        'message'=> 'Invalid Request Please Send POST request.',
        'status' => false


    ],JSON_PRETTY_PRINT);
    exit;
}



?>