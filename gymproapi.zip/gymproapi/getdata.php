<?php

//Users: POST Request
require_once __DIR__.'/function.php';
require_once __DIR__.'/class/Query.php';

header("Content-Type:application/json");


// for members Data REQUEST_CODE = 0, *****
// for Single Member Data REQUEST_CODE = 1, *******
// For Fees History Data REQUEST_CODE  =2  *******
// REQUEST CODE = 3 FOR GET NOTES DATA ***********

if($_SERVER['REQUEST_METHOD']=='POST'){

    $Request_Code = post('request_code');
    // for member data
    if($Request_Code == 0){

        $id = post('id');	
   
        $query = new Query();
        
        $result = $query->select('*')->table('members')->where([
          'created_by'=>$id      
        ])->AllRecords();
        
        if($result == false){
            
            echo json_encode([	
              'code'=> 200,
              'message' => 'No Members Found',
              'status'=> false,
              'data'=>[],
              'error'=> false
          ],JSON_PRETTY_PRINT);
          exit;
           
            
        }else{
                  echo json_encode([	
                      'code'=> 200,
                      'message' => 'Members Details Found',
                      'status'=> true,
                      'data'=>$result,
                      'error'=> false
                  ],JSON_PRETTY_PRINT);
                  exit;
                
            } 


    }
    // for Single Member Data
    if($Request_Code==1){
        
    $id = post('id');
    $created_by = post('created_by');	
   
    $query = new Query();
    
    $result = $query->select('*')->table('members')->where([
      'id'=>$id, 
      'created_by'=>$created_by 
    ])->AllRecords();
    
    if($result == false){
        
        echo json_encode([	
          'code'=> 200,
          'message' => 'No Members Found',
          'status'=> false,
          'data'=>[],
          'error'=> false
      ],JSON_PRETTY_PRINT);
      exit;
       
        
    }else{
        
    
              
              echo json_encode([	
                  'code'=> 200,
                  'message' => 'Members Details Found',
                  'status'=> true,
                  'data'=>$result,
                  'error'=> false
              ],JSON_PRETTY_PRINT);
              exit;
            
        } 
    }

    //for fee History

    if($Request_Code==2){
        
      $created_by = post('created_by');	
      $month = post('month');
     
      $query = new Query();
      
      $result = $query->select('*')->table('fees')->where([ 
        'created_by'=>$created_by,
        'fees_month'=>$month
      ])->AllRecords();

      $extra_data = $query->select('sum(amount) as amount')
      ->table('fees')
  ->where(['created_by'=>$created_by,
            'fees_month'=>$month])
  // ->concate('GROUP BY type')
  ->AllRecords();
    
      
      if($result == false){
          
          echo json_encode([	
            'code'=> 200,
            'message' => 'No Members Found',
            'status'=> false,
            'data'=>[],
            'error'=> false
        ],JSON_PRETTY_PRINT);
        exit;
         
          
      }else{
          
      
                
                echo json_encode([	
                    'code'=> 200,
                    'message' => 'Members Details Found',
                    'status'=> true,
                    'data'=>$result,
                    'extra_data'=>$extra_data,
                    'error'=> false
                ],JSON_PRETTY_PRINT);
                exit;
              
          } 
      }
      
      // FOR GET NOTES DATA
      
      $Request_Code = post('request_code');
    if($Request_Code == 3){

        $id = post('id');	
   
        $query = new Query();
        
        $result = $query->select('*')->table('notes')->where([
          'created_by'=>$id      
        ])->AllRecords();
        
        if($result == false){
            
            echo json_encode([	
              'code'=> 200,
              'message' => 'No Data Found',
              'status'=> false,
              'data'=>[],
              'error'=> false
          ],JSON_PRETTY_PRINT);
          exit;
           
            
        }else{
                  echo json_encode([	
                      'code'=> 200,
                      'message' => 'Data Found',
                      'status'=> true,
                      'data'=>$result,
                      'error'=> false
                  ],JSON_PRETTY_PRINT);
                  exit;
                
            } 


    }
      
    }else{
      
      echo json_encode([
      
          'code'=> 201,
          'message' => 'Invalid Request Please Send Post Request',
          'status'=> false,
          'data'=>[],
          'error'=> false
          
      
      ],JSON_PRETTY_PRINT);
      exit;
      
	
}



?>