<?php


require_once __DIR__.'/function.php';
require_once __DIR__.'/class/Query.php';

header("Content-Type:application/json");

if($_SERVER['REQUEST_METHOD']=='POST'){
     
    $query = new Query();

    $member_id = post('member_id');
    $created_by = post('gym_userid');
    $member_name = post('member_name');
    $member_mobile = post('member_mobile');
    $month = post('month');
    $amount = post('amount');
    $payment_type = post('payment_type');
    

    if($member_id =="" || $member_name =="" || $member_mobile=="" || $amount==""){
        echo json_encode([
            'code' => 404,
            'message'=> 'Please Provide Value',
            'status' => false,
            
        ],JSON_PRETTY_PRINT);
        exit;
    }

    try{
    $datasend = $query->insert('fees',[
        'member_id'=> $member_id,
        'created_by' => $created_by,
        'member_name'=> $member_name,
        'member_mobile'=> $member_mobile,
        'fees_month' => $month,
        'amount'=> $amount,
        'payment_type'=> $payment_type

    ]);

    echo json_encode([
        'code' => 200,
        'message'=> 'Fees Deposit Success',
        'status' => true,
        
    ],JSON_PRETTY_PRINT);
    exit;
    }catch(Exception $e){
        echo json_encode([
            'code' => 200,
            'message'=> 'Server Error',
            'status' => false
    
        ],JSON_PRETTY_PRINT);
        exit;
    }

}else{

    echo json_encode([
        'code' => 201,
        'message'=> 'Invalid Request Please Send POST request.',
        'status' => false,

    ],JSON_PRETTY_PRINT);
    exit;
}



?>